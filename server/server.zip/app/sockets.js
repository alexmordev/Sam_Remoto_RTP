// const ReaderPCSC = require('./reader');
const smartcard = require('smartcard');
const Devices = smartcard.Devices;

class Sockets {
    constructor(io){
        this.io = io;
        // this.reader = new Devices();
        this.socketEvents();
        // this.reader = new ReaderPCSC();
    }

    socketEvents(){
        // let dev = this.reader;
        this.io.on("connection", (socket) => {
            const readers = new Devices();
            console.log('cliente conectado');
            readers.on('device-activated', event => {
                let device = event.device;
                socket.emit('status-device', device);

                device.on('card-inserted', event => {
                    let card = event.card;
                    socket.emit('status-device', card.getAtr());
                });

                device.on('card-removed', event => {
                    socket.emit('status-device', 'card removed');
                });
            });

            readers.on('device-deactivated', event => {
                const data = {
                    "msg": "no hay conexion"
                }
                socket.emit('status-device', data);
            });
            
        });
    }

}

module.exports = Sockets;