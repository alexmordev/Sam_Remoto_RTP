const counters =
{
    contadores: [
        0,
        0,
        0,
        150,
        0,
        0,
        0,
        2,
        2,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        9,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0
    ],
    samSerial: "aec11a4e",
    status: "Correct Execution",
    Time: 20
    
}
// console.log(counters.contadores[0]);
// const [p1] = counters.contadores
// console.log()
const prueba = counters.contadores 
// console.log(prueba[3]);


module.exports = counters;