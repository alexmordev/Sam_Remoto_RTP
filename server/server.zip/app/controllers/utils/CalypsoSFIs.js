const CalypsoSFIs ={
    "sfis":{
        "SFI_ENVIRONMENT" : "0x7",
        "SFI_EVENTLOG" : "0x8",
        "SFI_CONTRACTS" : "0x9"
    } 
};
module.exports={
    CalypsoSFIs
}