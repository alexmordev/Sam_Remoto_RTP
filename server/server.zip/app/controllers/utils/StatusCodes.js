const StatusCodes = 
{
    "response":{
        "6985":"Sam is Locked",
        "6700":"Incorrect Lc",
        "6900":"An event counter cannot be incremented",
        "6982": "Security conditions not fulfilled",
        "6985":"Preconditions not satisfied",
        "6A00":"Incorrect P1 or P2",
        "6A83":"Record not Found",
        "6D00":"Instruccion Unknow",
        "6E00":"Class Not supported",
        "9000": "Correct Execution"
    }
};
module.exports= StatusCodes;