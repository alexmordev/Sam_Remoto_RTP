# para descargar la base de datos, genera el siguiente comando
# npx sequelize-cli db:migrate
# ...............................................................
# Para obtener los seeders, ejecutar el siguiente comando el siguiente
# npx sequelize-cli db:seed:all
# ...............................................................
# Control_Acceso_Nuevo
# Instalaciones requeridas 
# npm install --save sequelize-cli
# npm install --save sequelize
# npm install --save pg pg-hstore
# npm i jsonwebtoken
# npm i cookie-parser
# npm i bcrypt
# npm nodemon
# npm i express
# npm i dotenv# Acces_Rp
# Control_acceso_rtp
# acceso_nuevo
# Control_nuevo

